using UnityEngine;

public class ControlSelector : MonoBehaviour
{
    public GameObject controlPanel; // Panel con los botones
    private bool usingGyroscope = false;

    void Start()
    {
        // Mostrar el panel de opciones al iniciar
        controlPanel.SetActive(true);

        // Aseg�rate de que el giroscopio est� disponible
        if (!SystemInfo.supportsGyroscope)
        {
            Debug.LogError("El dispositivo no soporta giroscopio");
        }
    }

    // Funci�n para elegir Giroscopio
    public void SelectGyroscope()
    {
        usingGyroscope = true;
        controlPanel.SetActive(false); // Ocultar el panel de opciones
        Debug.Log("Control seleccionado: Giroscopio");
    }

    // Funci�n para elegir Aceler�metro
    public void SelectAccelerometer()
    {
        usingGyroscope = false;
        controlPanel.SetActive(false); // Ocultar el panel de opciones
        Debug.Log("Control seleccionado: Aceler�metro");
    }

    void Update()
    {
        // Activar el control correspondiente seg�n la selecci�n
        if (usingGyroscope)
        {
            if (Input.gyro.enabled == false)
            {
                Input.gyro.enabled = true;
            }
            // Aqu� agregar la l�gica de control con giroscopio
            Vector3 gyroRotation = Input.gyro.rotationRateUnbiased;
            // Utilizar `gyroRotation` para mover el objeto o lanzar los residuos
        }
        else
        {
            // Usar el aceler�metro
            Vector3 acceleration = Input.acceleration;
            // Utilizar `acceleration` para mover el objeto o lanzar los residuos
        }
    }
}
