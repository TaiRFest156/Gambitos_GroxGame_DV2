using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using TMPro;

public class LevelSelector : MonoBehaviour
{
    public GameObject levelButtonPrefab;  // Prefab del bot�n de nivel
    public Transform buttonContainer;  // Contenedor de los botones
    public int totalLevels = 2;  // N�mero total de niveles

    void Start()
    {
        GenerateLevelButtons();
    }

    // M�todo para generar los botones para cada nivel
    void GenerateLevelButtons()
    {
        for (int i = 1; i <= totalLevels; i++)
        {
            GameObject buttonObj = Instantiate(levelButtonPrefab, buttonContainer);
            buttonObj.GetComponentInChildren<TextMeshProUGUI>().text = "Nivel " + i;

            int levelIndex = i;
            buttonObj.GetComponent<Button>().onClick.AddListener(() =>
            {
                // Cargar el nivel seleccionado
                SceneManager.LoadScene("Nivel_" + levelIndex);
            });
        }
    }

    // M�todo para regresar al men� principal
    public void ReturnToMenu()
    {
        SceneManager.LoadScene("Start_Menu");
    }
}
