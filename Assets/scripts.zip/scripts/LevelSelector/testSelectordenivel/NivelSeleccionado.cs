public static class NivelSeleccionado
{
    public static int Nivel = 1; // lo cambia el bot�n del men�
}